package com.example.contacts_arwashamaly;

public interface OnAction {
    void onChooseName(int position);
}
